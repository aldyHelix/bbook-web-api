@extends('layouts.app')

@section('page-title', __('Dashboard'))

@section('content')
    @include('partials.messages')
<div class="content-body">
    Konten Dashboard disini.
</div>
@stop

@section('scripts')

@stop
