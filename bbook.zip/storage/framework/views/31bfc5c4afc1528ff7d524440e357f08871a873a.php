<?php $__env->startSection('page-title', __('Materi')); ?>
<?php $__env->startSection('page-heading', __('Materi Pra-Sejarah')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="content-types">
    <div class="row match-height">
    <?php if(count($materis)): ?>
    <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-4 col-md-6">
        <div class="card">
          <div class="card-header mb-1">
            <h4 class="card-title"><?php echo e($d->nama_materi); ?></h4>
            <div>
                <a href="<?php echo e(url('materi/edit/'.$d->id)); ?>" class="btn btn-icon"
                    title="<?php echo app('translator')->get('Edit'); ?>" data-toggle="tooltip" data-placement="top">
                        <i class="feather icon-edit"></i>
                </a>
                <a href="<?php echo e(url('materi/delete/'.$d->id)); ?>" class="btn btn-icon"
                    title="<?php echo app('translator')->get('Delete'); ?>" data-toggle="tooltip" data-placement="top">
                    <i class="feather icon-trash"></i>
                </a>
            </div>
          </div>
          <div class="card-content">
            <?php if($d->gambar_materi != null ): ?>
            <img class="img-fluid" src="<?php echo e($d->getPhoto()); ?>">
            <?php else: ?>
            <img class="img-fluid" src="<?php echo e(defaultPhoto()); ?>">
            <?php endif; ?>
            <div class="card-body">
              <p class="card-text"><?php echo e($d->deskripsi); ?></p>
            </div>
          </div>
          <div class="card-footer text-muted">
            <span class="float-left">Updated <?php echo e(time_elapsed_string($d->updated_at)); ?></span>
            <span class="float-right">
              <a href="<?php echo e(url('materi/detail/'.$d->id)); ?>" class="card-link">More Details <i class="fa fa-angle-right"></i></a>
            </span>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <div class="col-xl-4 col-md-6">
        <div class="card">
          <div class="card-header mb-1">
            <h4 class="card-title">No Record Found</h4>
          </div>
        </div>
    </div>
    <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bbook\resources\views/materi/index.blade.php ENDPATH**/ ?>