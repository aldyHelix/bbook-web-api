<?php $__env->startSection('page-title', __('User')); ?>
<?php $__env->startSection('page-heading', __('User List')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-lg-12">
                <div class="float-right">
                        <a href="<?php echo e(url('end-user/add')); ?>" class="btn btn-outline-primary">
                            <i class="feather icon-plus mr-2"></i>
                            <?php echo app('translator')->get('Add User'); ?>
                        </a>
                    </div>
                </div>
            </div>

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th class="min-width-100"><?php echo app('translator')->get('No'); ?></th>
                        <th class="min-width-100"><?php echo app('translator')->get('Name'); ?></th>
                        <th class="min-width-150"><?php echo app('translator')->get('Username'); ?></th>
                        <th class="min-width-150"><?php echo app('translator')->get('Email'); ?></th>
                        <th class="min-width-150"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                            <?php if(count($users)): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no+1); ?></td>
                                        <td><?php echo e($d->name); ?></td>
                                        <td><?php echo e($d->username); ?></td>
                                        <td><?php echo e($d->email); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('end-user/edit/'.$d->id)); ?>" class="btn btn-icon"
                                                title="<?php echo app('translator')->get('Edit'); ?>" data-toggle="tooltip" data-placement="top">
                                                    <i class="feather icon-edit"></i>
                                            </a>
                                            <a href="<?php echo e(url('end-user/delete/'.$d->id)); ?>" class="btn btn-icon"
                                                title="<?php echo app('translator')->get('Delete'); ?>" data-toggle="tooltip" data-placement="top">
                                                <i class="feather icon-trash"></i>
                                            </a>
                                            <a href="<?php echo e(url('end-user/answer/'.$d->id)); ?>" class="btn btn-icon"
                                                title="<?php echo app('translator')->get('Answer'); ?>" data-toggle="tooltip" data-placement="top">
                                                    <i class="feather icon-layers"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5"><em><?php echo app('translator')->get('No records found.'); ?></em></td>
                                </tr>
                            <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bbook\resources\views/users/index.blade.php ENDPATH**/ ?>