<?php $__env->startSection('page-title', __('Konten')); ?>
<?php $__env->startSection('page-heading', __('Konten '.$konten->kontenMateri->nama_materi)); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(url('/')); ?>"><?php echo app('translator')->get('Konten'); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="basic-media-object">
    <div class="row match-height">
      <div class="col-xl-6 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"><?php echo e($konten->kontenMateri->nama_materi); ?></h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <p>
                        <?php echo e($konten->kontenMateri->fill_deskripsi); ?>

                    </p>
                    <div class="media-list">
                        <div class="media">
                            <a class="media-left">
                                <img src="<?php echo e($konten->getHeader()); ?>" alt="No Image"
                                height="64" width="64" />
                            </a>
                            <a class="media-left">
                                <img src="<?php echo e($konten->getGambar1()); ?>" alt="No Image"
                                height="64" width="64" />
                            </a>
                            <a class="media-left">
                                <img src="<?php echo e($konten->getGambar2()); ?>" alt="No Image"
                                height="64" width="64" />
                            </a>
                            <a class="media-left">
                                <img src="<?php echo e($konten->getGambar3()); ?>" alt="No Image"
                                height="64" width="64" />
                            </a>
                            <a class="media-left">
                                <img src="<?php echo e($konten->getGambar4()); ?>" alt="No Image"
                                height="64" width="64" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>

    </div>
</section>
<section id="basic-media-object">
    <div class="row match-height">
        <div class="col-xl-12 col-lg-12">
            <div class="card">
            <div class="card-header">
                <h4 class="card-title"><?php echo e($konten->kontenMateri->nama_materi); ?> Video Content</h4>
            </div>
            <div class="card-content">
                <div class="card-body">

                <div class="media-list">
                    <div class="media">
                        <div class="video-player" id="plyr-video-player">
                            <video width="640" controls>
                                <source src="<?php echo e($konten->video_stream); ?>" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bbook\resources\views/konten/details.blade.php ENDPATH**/ ?>