<?php $__env->startSection('page-title', __('Materi Detail')); ?>
<?php $__env->startSection('page-heading', 'Materi Details '.$materi->nama_materi); ?>
<?php $__env->startSection('mystyle'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset('mix-assets/css/pages/users.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(url('/materi')); ?>"><?php echo app('translator')->get('Materi'); ?></a>
    </li>
    <li class="breadcrumb-item active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
      <div class="col-lg-3 col-12">
        <div class="card">
          <div class="card-header">
            <h4>Materi</h4>
          </div>
          <div class="card-body">
            <small><?php echo e($materi->deskripsi); ?></small>
            <hr>
            <p style="text-align: justify;"><?php echo e($materi->fill_deskripsi); ?></p>
            <div class="mt-1">
              <h6 class="mb-0">Dibuat :</h6>
              <p><?php echo e(date_format(date_create($materi->created_at), "d-m-Y")); ?></p>
            </div>
            <div class="mt-1">
              <h6 class="mb-0">QR:</h6>
              <small>QR dapat ditempatkan di Buku Cetak untuk di scan.</small>
              <?php echo QR::size(200)->generate($materi->qr); ?>

            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-5 col-12">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-start align-items-center mb-1">
              <div class="avatar mr-1">
                <img src="<?php echo e($materi->gambar_materi != null ? $materi->getPhoto() : defaultPhoto()); ?>" alt="avtar img holder" height="45" width="45">
              </div>
              <div class="user-page-info">
                <h6 class="mb-0"><?php echo e($materi->nama_materi); ?></h6>
              </div>
            </div>
           <iframe src="<?php echo e($materi->link_materi); ?>" class="w-100 height-250"></iframe>
          </div>
        </div>
        <?php if(count($materi->kontenMateri) != 0): ?>
        <?php $__currentLoopData = $materi->kontenMateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Konten Lists -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-3 mr-1">
                            <img height="100" width="auto" src="<?php echo e($dt->gambar_konten != null ? $dt->getPhoto() : defaultPhoto()); ?>">
                        </div>
                        <div class="col-sm-7">
                            <?php echo e($dt->description); ?>

                        </div>
                        <div class="col-sm-1">
                            <a data-toggle="modal" data-target="#editkonten<?php echo e($dt->id); ?>"><i class="feather icon-edit cursor-pointer" href="#"></i></a>
                            <hr>
                            <a class="danger" href="<?php echo e(url('konten/delete/'.$dt->id)); ?>"><i class="feather icon-trash cursor-pointer"></i></a>
                       </div>
                        <div class="modal fade text-left" id="editkonten<?php echo e($dt->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="myModalLabel17" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel17">Tambah Konten</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo Form::open(['url' => 'konten/update/'.$dt->id , 'method' => 'PUT', 'id' => 'form', 'enctype'=>'multipart/form-data']); ?>

                                        <input type="hidden" value="<?php echo e($materi->id); ?>" name="dt[materi_id]">
                                        <div class="form-group text-center">
                                            <img height="100" width="auto" src="<?php echo e($dt->gambar_konten != null ? $dt->getPhoto() : defaultPhoto()); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="basicInputFile">Gambar Konten</label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="inputGroupFile01" name="gambar_konten">
                                                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Deskripsi</label>
                                            <textarea type="text" class="form-control input-solid" placeholder="Deskripsi" name="desc" value="<?php echo e($dt->description); ?>"><?php echo e($dt->description); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Konten -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="card">
            <div class="card-header mb-1">
                <h4 class="card-title">No Konten Record Found</h4>
            </div>
        </div>
        <?php endif; ?>
      </div>
      <div class="col-lg-4 col-12">
        <div class="card">
            <div class="card-body">
                <button type="button" class="btn btn-outline-primary mr-1 mb-1 block" data-toggle="modal" data-target="#addkonten"><i class="feather icon-plus" ></i> Add Konten</button>
                <button type="button" class="btn btn-outline-primary mr-1 mb-1 block" data-toggle="modal" data-target="#addquiz"><i class="feather icon-plus"></i> Add Quiz</button>
            </div>
        </div>
        <?php if(count($materi->quizMateri) != 0): ?>
        <?php $__currentLoopData = $materi->quizMateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Konten Lists -->
            <div class="card">
                <div class="card-body">
                    <p><?php echo e($dt->question); ?></p>
                    <ul class="list-group">
                        <?php if(count($dt->hasOption) != 0): ?>
                        <?php $__currentLoopData = $dt->hasOption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center <?php echo e($opt->is_answer ? 'active' : ''); ?>"><span><?php echo e($opt->option); ?>. <?php echo e($opt->description_option); ?></span>
                                <span class="badge ">
                                <a data-toggle="modal" data-target="#delopt<?php echo e($dt->id); ?>"><i class="feather icon-edit cursor-pointer" href="#"></i></a>
                                <a data-toggle="modal" data-target="#editopt<?php echo e($dt->id); ?>"><i class="feather icon-trash cursor-pointer" href="#"></i></a>
                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <li class="list-group-item">No Option Found</li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-sm-12 mr-1 text-center">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#addopt<?php echo e($dt->id); ?>"><i class="feather icon-plus"></i></button>
                                <button type="button" class="btn btn-outline-info" data-toggle="modal" data-target="#editquiz<?php echo e($dt->id); ?>"><i class="feather icon-edit"></i></button>
                                <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#delquiz<?php echo e($dt->id); ?>"><i class="feather icon-trash"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<!-- Modal edit quiz -->
<div class="modal fade text-left" id="editquiz<?php echo e($dt->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel17" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel17">Tambah Quiz</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
        <form>
           <input type="hidden" value="<?php echo e($materi->id); ?> name=dt[materi_id]">
            <div class="form-group">
                <label for="basicInputFile">Gambar Quiz</label>
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="inputGroupFile01" name="header">
                    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                </div>
            </div>
            <div class="form-group">
                <label for="email">Question</label>
                <textarea type="text" class="form-control input-solid" placeholder="Deskripsi full" name="dt[description]"></textarea>
            </div>
            <div class="form-group">
                <label for="email">Answer</label>
                <textarea type="text" class="form-control input-solid" placeholder="Deskripsi full" name="dt[description]"></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Accept</button>
        </div>
        </form>
        </div>
    </div>
</div>
            <!-- End Konten -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="card">
            <div class="card-header mb-1">
                <h4 class="card-title">No Quiz Record Found</h4>
            </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
<div class="modal fade text-left" id="addkonten" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel17" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel17">Tambah Konten</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo Form::open(['url' => 'konten/insert', 'id' => 'form', 'enctype'=>'multipart/form-data']); ?>

                <input type="hidden" value="<?php echo e($materi->id); ?>" name="dt[materi_id]">
                <div class="form-group">
                    <label for="basicInputFile">Gambar Konten</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="inputGroupFile01" name="gambar_konten">
                        <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                    </div>
                </div>
                <div class="form-group">
                    <label for="email">Deskripsi</label>
                    <textarea type="text" class="form-control input-solid" placeholder="Deskripsi" name="desc"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade text-left" id="addquiz" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel17" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel17">Tambah Quiz</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
        <form>
           <input type="hidden" value="<?php echo e($materi->id); ?> name=dt[materi_id]">
            <div class="form-group">
                <label for="basicInputFile">Gambar Quiz</label>
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="inputGroupFile01" name="header">
                    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                </div>
            </div>
            <div class="form-group">
                <label for="email">Question</label>
                <textarea type="text" class="form-control input-solid" placeholder="Deskripsi full" name="dt[description]"></textarea>
            </div>
            <div class="form-group">
                <label for="email">Answer</label>
                <textarea type="text" class="form-control input-solid" placeholder="Deskripsi full" name="dt[description]"></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Accept</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bbook\resources\views/materi/details.blade.php ENDPATH**/ ?>